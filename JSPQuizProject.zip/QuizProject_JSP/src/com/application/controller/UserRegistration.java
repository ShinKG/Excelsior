package com.application.controller;

import java.sql.Connection;
import java.io.IOException;
import java.sql.Statement;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.application.model.DBConnector;

@WebServlet("/UserRegistration")
public class UserRegistration extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		String school = request.getParameter("school");
		
		String SQL = "INSERT INTO users(username, password, email, school)"
				+ " VALUES('"+username+"', '"+password+"', '"+email+"', '"+school+"')";
		
		String Message = "";
		
		Connection DBConnection = DBConnector.createConnection();
		
		try {
			
			Statement st = DBConnection.createStatement();
			
			// Print SQL in console to verify if data is received
			System.out.println(SQL);
			
			st.executeUpdate(SQL);
			
			Message = "Registration Successful";
			
		} catch (SQLException e) {
			
			System.out.println("Error Inserting Record to Database");
			Message = "An Error Occurred During Your Registration";
			
			e.printStackTrace();
			
		}
		
		try {
			DBConnection.close();
		} catch (SQLException e) {
			
			System.out.println("Error Closing Connection");
			Message = "An Error Occurred During Your Registration";
			
			e.printStackTrace();
			
		}
		
		request.setAttribute("newUser", username);
		
		request.getSession().setAttribute("alert", Message);
		
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
		requestDispatcher.forward(request, response);
	}

}
