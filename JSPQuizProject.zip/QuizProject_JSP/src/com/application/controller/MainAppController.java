package com.application.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = { "/home", "/login", "/register", "/startQuiz", "/logout" })
public class MainAppController extends HttpServlet {
	
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String AppContextPath = request.getContextPath();
		
		if (request.getRequestURI().equals(AppContextPath + "/home")) {
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/home.jsp");
			requestDispatcher.forward(request, response);
			
		} else if (request.getRequestURI().equals(AppContextPath + "/login")) {
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
			requestDispatcher.forward(request, response);
			
		} else if (request.getRequestURI().equals(AppContextPath + "/register")) {
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/registration.jsp");
			requestDispatcher.forward(request, response);
			
		} else if (request.getRequestURI().equals(AppContextPath + "/startQuiz")) {
			
			request.getSession().setAttribute("currentQuiz", null);
			
			String Quiz = request.getParameter("quiz");
			request.getSession().setAttribute("quiz", Quiz);
			
			System.out.println(request.getSession().getAttribute("user"));
			
			if (request.getSession().getAttribute("user") == null) {
				
				request.getRequestDispatcher("/login").forward(request, response);
				
			} else {
				
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/quiz_details.jsp");
				requestDispatcher.forward(request, response);
				
			}
			
		} else if (request.getRequestURI().equals(AppContextPath + "/logout")) {
			
			request.getSession().setAttribute("user", null);
			request.getSession().invalidate();
			
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
			requestDispatcher.forward(request, response);
			
		}
		
	}

}
