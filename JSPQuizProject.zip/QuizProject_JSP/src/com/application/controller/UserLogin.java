package com.application.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.application.model.DBConnector;

@WebServlet("/UserLogin")
public class UserLogin extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String SQL = "";
		String username = "";
		String password = "";
		
		Connection DBConnection = null;
		ResultSet userSet = null;
		
		username = request.getParameter("username");
		password = request.getParameter("password");
		
		DBConnection = DBConnector.createConnection();
		
		int i = 0;
		
		try {
			
			Statement st = DBConnection.createStatement();
			SQL = "SELECT * FROM users WHERE username = '"+username+"' AND password = '"+password+"'";
			userSet = st.executeQuery(SQL);
			
			while (userSet.next()) {
				i = 1;
			}
			
			if (i != 0) {
				
				HttpSession session = request.getSession();
				session.setAttribute("user", username);
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/home.jsp");
				requestDispatcher.forward(request, response);
				
			} else {
				
				request.setAttribute("errorMessage", "Invalid username or password");
				RequestDispatcher requestDispatcher = request.getRequestDispatcher("/index.jsp");
				requestDispatcher.forward(request, response);
				
			}
			
		} catch (SQLException e) {
			System.out.println("Error Fetching Records from Database");
			e.printStackTrace();
		}
		
		try {
			DBConnection.close();
		} catch (SQLException e) {
			System.out.println("Error Closing Connection");
			e.printStackTrace();
		}
		
	}

}
