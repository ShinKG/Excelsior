package com.application.controller;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.application.model.Quiz;
import com.application.model.QuizQuestion;

@WebServlet("/Quiz")
public class QuizController extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		boolean endQuiz = false;
		
		HttpSession session = request.getSession();
		
		try {
			
			if (session.getAttribute("currentQuiz") == null) {
				
				session = request.getSession();
				
				String SelectedQuiz = (String) request.getSession().getAttribute("quiz");
				System.out.println("Setting Quiz: "+SelectedQuiz);
				
				Quiz quiz = new Quiz(SelectedQuiz);
				session.setAttribute("currentQuiz", quiz);
				
				SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss a");
				Date quizDate = new Date();
				String DateStarted = dateFormat.format(quizDate);
				
				session.setAttribute("dateStarted", DateStarted);
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		Quiz quiz = (Quiz) request.getSession().getAttribute("currentQuiz");
		
		if (quiz.currentQuestion == 0) {
			
			quiz.setQuestion(quiz.currentQuestion);
			QuizQuestion question = quiz.questionList.get(quiz.currentQuestion);
			session.setAttribute("question", question);
		}
		
		String Action = request.getParameter("action");
		String RadioButton = request.getParameter("answer");
		int selectedOption = -1;
		
		quiz.selections.put(quiz.currentQuestion, selectedOption);
		
		if ("1".equals(RadioButton)) {
			
			selectedOption = 1;
			quiz.selections.put(quiz.currentQuestion, selectedOption);
			System.out.println("Selected Option: " + selectedOption);
			
		} else if ("2".equals(RadioButton)) {
			
			selectedOption = 2;
			quiz.selections.put(quiz.currentQuestion, selectedOption);
			System.out.println("Selected Option: " + selectedOption);
			
		} else if ("3".equals(RadioButton)) {
			
			selectedOption = 3;
			quiz.selections.put(quiz.currentQuestion, selectedOption);
			System.out.println("Selected Option: " + selectedOption);
			
		} else if ("4".equals(RadioButton)) {
			
			selectedOption = 4;
			quiz.selections.put(quiz.currentQuestion, selectedOption);
			System.out.println("Selected Option: " + selectedOption);
			
		} else if ("5".equals(RadioButton)) {
			
			selectedOption = 5;
			quiz.selections.put(quiz.currentQuestion, selectedOption);
			System.out.println("Selected Option: " + selectedOption);
			
		}
		
		if ("Next".equals(Action)) {
			
			quiz.currentQuestion++;
			quiz.setQuestion(quiz.currentQuestion);
			QuizQuestion quizQuestion = quiz.questionList.get(quiz.currentQuestion);
			session.setAttribute("question", quizQuestion);
			
		} else if ("Previous".equals(Action)) {
			
			quiz.currentQuestion--;
			quiz.setQuestion(quiz.currentQuestion);
			QuizQuestion quizQuestion = quiz.questionList.get(quiz.currentQuestion);
			session.setAttribute("question", quizQuestion);
			
		} else if ("Submit".equals(Action)) {
			
			endQuiz = true;
			int score = quiz.calculateResult(quiz);
			request.setAttribute("quizScore", score);
			request.getSession().setAttribute("currentQuiz", null);
			request.getRequestDispatcher("/quiz_result.jsp").forward(request, response);
			
		}
		
		if (endQuiz != true) {
			request.getRequestDispatcher("/quiz_page.jsp").forward(request, response);
		}
		
	}

}
