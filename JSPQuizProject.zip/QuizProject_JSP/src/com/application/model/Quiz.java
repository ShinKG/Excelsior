package com.application.model;

import java.io.IOException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.application.model.CreateDOM;

public class Quiz {
	
	Document DOM;
	public int currentQuestion = 0;
	
	public Map<Integer, Integer> selections = new LinkedHashMap<Integer, Integer>();
	public ArrayList<QuizQuestion> questionList = new ArrayList<QuizQuestion>(5);
	
	public Quiz(String Quiz) throws SAXException, ParserConfigurationException, IOException, URISyntaxException {
		DOM = CreateDOM.getDOM(Quiz);
	}
	
	public void setQuestion(int i) {
		
		int questionNumber = i;
		String Options[] = new String[5];
		String Question = null;
		int keyOptionIndex = 0;
		
		System.out.println("DOM " + DOM);
		
		NodeList questionNodeList = DOM.getElementsByTagName("question");
		NodeList childList = questionNodeList.item(i).getChildNodes();
		
		int optionCtr = 0;
		
		for (int loopCtr = 0; loopCtr < childList.getLength(); loopCtr++) {
			
			Node childNode = childList.item(loopCtr);
			
			if ("answer".equals(childNode.getNodeName())) {
				
				Options[optionCtr] = childList.item(loopCtr).getTextContent();
				optionCtr++;
				
			} else if ("description".equals(childNode.getNodeName())) {
				
				Question = childList.item(loopCtr).getTextContent();
				
			} else if ("key".equals(childNode.getNodeName())) {
				
				keyOptionIndex = Integer.parseInt(childList.item(loopCtr).getTextContent());
				
			}
			
		}
		
		System.out.println("Question Number: " + questionNumber);
		System.out.println("Question: " + Question);
		
		for (String A:Options) {
			System.out.println(A);			
		}
		
		System.out.println("Correct Answer Index: " + keyOptionIndex);
		
		QuizQuestion quizQuestion = new QuizQuestion();
		quizQuestion.setQuestionNumber(questionNumber);
		quizQuestion.setQuestion(Question);
		quizQuestion.setKeyOptionIndex(keyOptionIndex);
		quizQuestion.setQuestionOptions(Options);
		questionList.add(questionNumber, quizQuestion);
		
	}
	
	public ArrayList<QuizQuestion> getQuestionList() {
		return this.questionList;
	}
	
	public int getCurrentQuestion() {
		return currentQuestion;
	}
	
	public Map<Integer, Integer> getSelections() {
		return this.selections;
	}
	
	public int calculateResult(Quiz quiz) {
		
		int totalCorrect = 0;
		
		Map<Integer, Integer> userSelectionsMap = quiz.selections;
		List<Integer> userSelectionsList = new ArrayList<Integer>(5);
		
		for (Map.Entry<Integer, Integer> entry: userSelectionsMap.entrySet()) {
			userSelectionsList.add(entry.getValue());
		}
		
		List<QuizQuestion> questionList = quiz.questionList;
		List<Integer> keyAnswersList = new ArrayList<Integer>(5);
		
		for (QuizQuestion question: questionList) {
			
			keyAnswersList.add(question.getKeyOptionIndex());
			
		}
		
		for (int ctr = 0; ctr < selections.size(); ctr++) {
			
			System.out.println(userSelectionsList.get(ctr) + " : " + keyAnswersList.get(ctr));
			
			if ((userSelectionsList.get(ctr) - 1) == keyAnswersList.get(ctr)) {
				totalCorrect++;
			}
			
		}
		
		System.out.println("Correct Answers: " + totalCorrect);
		return totalCorrect;
		
	}

}
