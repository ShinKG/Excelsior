package com.application.model;

public class QuizQuestion {
	
	int questionNumber;
	int keyOptionIndex;
	String Question;
	String QuestionOptions[];
	
	public int getQuestionNumber() {
		return questionNumber;
	}
	public void setQuestionNumber(int qNum) {
		questionNumber = qNum;
	}
	
	public String getQuestion() {
		return Question;
	}
	public void setQuestion(String Q) {
		Question = Q;
	}
	
	public int getKeyOptionIndex() {
		return keyOptionIndex;
	}
	public void setKeyOptionIndex(int optionIndex) {
		keyOptionIndex = optionIndex;
	}
	
	public String[] getQuestionOptions() {
		return QuestionOptions;
	}
	public void setQuestionOptions(String[] QOptions) {
		QuestionOptions = QOptions;
	}

}
