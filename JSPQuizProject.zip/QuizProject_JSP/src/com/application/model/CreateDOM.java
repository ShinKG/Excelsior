package com.application.model;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URISyntaxException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class CreateDOM {
	
	public static Document getDOM(String Quiz) throws SAXException, ParserConfigurationException, IOException, URISyntaxException {
		
		Document DOM = null;
		File quizFile = null;
		
		quizFile = new File("/Users/JC Ramos/eclipse-workspace/QuizProject_JSP/WebContent/WEB-INF/jsp-"+Quiz+".xml");
		System.out.println("Quiz XML File Absolute Path: "+quizFile.getAbsolutePath());
		
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		
		try {
			DOM = db.parse(quizFile);
		} catch (FileNotFoundException fileNotFound) {
			System.out.println("Quiz File Not Found" + fileNotFound);
		}
		
		DOM.getDocumentElement().normalize();
		return DOM;
		
	}

}
