package com.application.model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnector {
	
	private static String DBURL = "jdbc:mysql://localhost/jspquiz_webtechfinals";
	private static String DBUser = "root";
	private static String DBPassword = "";

	public static Connection createConnection() {
		
		Connection DBConnection = null;
		
		try {
			
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				System.out.println("Error Loading Driver Class");
				System.exit(1);
			}
			
			DBConnection = DriverManager.getConnection(DBURL, DBUser, DBPassword);
			
		} catch (SQLException e) {
			System.out.println("Error Creating a Connection to the Database");
			e.printStackTrace();
		}
		
		return DBConnection;
		
	}
	
}
